package com.xiaohei.common.widget.recycler;

public class RecyclerAdapter extends Recycle  {
}

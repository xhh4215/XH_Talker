package com.xiaohei.common.widget.recycler;

public interface AdaoterCallback {


}
